var reportContainer = document.getElementById('reportContainer');
var report = powerbi.embed(reportContainer);